---
name: Curated Manuscript Aesthetic
colors:
  surface: '#fcf9f8'
  surface-dim: '#dcd9d9'
  surface-bright: '#fcf9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3f2'
  surface-container: '#f0eded'
  surface-container-high: '#eae7e7'
  surface-container-highest: '#e5e2e1'
  on-surface: '#1c1b1b'
  on-surface-variant: '#43474c'
  inverse-surface: '#313030'
  inverse-on-surface: '#f3f0ef'
  outline: '#74777d'
  outline-variant: '#c4c6cd'
  surface-tint: '#4e6073'
  primary: '#162839'
  on-primary: '#ffffff'
  primary-container: '#2c3e50'
  on-primary-container: '#96a9be'
  inverse-primary: '#b5c8df'
  secondary: '#5f5e5b'
  on-secondary: '#ffffff'
  secondary-container: '#e1dfdb'
  on-secondary-container: '#63635f'
  tertiary: '#282720'
  on-tertiary: '#ffffff'
  tertiary-container: '#3e3d35'
  on-tertiary-container: '#aaa79d'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d1e4fb'
  primary-fixed-dim: '#b5c8df'
  on-primary-fixed: '#091d2e'
  on-primary-fixed-variant: '#36485b'
  secondary-fixed: '#e4e2dd'
  secondary-fixed-dim: '#c8c6c2'
  on-secondary-fixed: '#1b1c19'
  on-secondary-fixed-variant: '#474744'
  tertiary-fixed: '#e6e2d7'
  tertiary-fixed-dim: '#cac6bc'
  on-tertiary-fixed: '#1c1c15'
  on-tertiary-fixed-variant: '#48473f'
  background: '#fcf9f8'
  on-background: '#1c1b1b'
  surface-variant: '#e5e2e1'
typography:
  display-xl:
    fontFamily: Syne
    fontSize: 80px
    fontWeight: '800'
    lineHeight: '1.0'
    letterSpacing: -0.04em
  headline-lg:
    fontFamily: Syne
    fontSize: 48px
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Syne
    fontSize: 32px
    fontWeight: '800'
    lineHeight: '1.2'
  body-lg:
    fontFamily: Lora
    fontSize: 20px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Lora
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-caps:
    fontFamily: Work Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: '1.0'
    letterSpacing: 0.1em
spacing:
  unit: 8px
  container-max: 1120px
  gutter: 32px
  margin-page: 64px
  section-gap: 128px
---

## Brand & Style

This design system is rooted in the "Curated Manuscript" aesthetic—a sophisticated blend of editorial minimalism and historical gravitas. It targets a discerning audience that values intellectual depth, professional authority, and tactile quality in a digital environment. 

The visual narrative is driven by an obsession with whitespace and high-contrast typography, evoking the feeling of a limited-edition lithograph or a high-end architectural journal. By stripping away decorative clutter, the focus is placed entirely on content, creating an emotional response of focused calm and unwavering credibility. The style is strictly Minimalist with an emphasis on "ink-on-paper" physicality.

## Colors

The palette is restrained and intentional, simulating the natural aging of premium stock and the density of fresh ink.

- **Primary (Slate Navy):** Used for all functional elements, heavy headings, and primary calls to action. This provides a professional, "archival" depth compared to standard black.
- **Secondary (Warm Parchment):** The foundation of the system. This off-white provides a soft, low-strain reading experience that feels warmer and more premium than pure white.
- **Tertiary (Milled Stone):** Used for subtle structural divides, hover states, and background layering to maintain depth without breaking the minimalist aesthetic.
- **Text (Charcoal Ink):** Reserved for body copy to ensure maximum legibility while maintaining a soft, organic contrast against the parchment background.

## Typography

Typography is the primary visual driver of this design system. We use a high-tension pairing of an ultra-bold geometric sans-serif and a traditional literary serif.

- **Headings:** Syne (ExtraBold 800) creates a contemporary, architectural impact. It should be used with tight tracking and leading to create "blocks" of ink.
- **Body:** Lora (Regular 400) provides a classic, readable experience. The line height is intentionally generous (1.6) to facilitate long-form reading and reinforce the editorial vibe.
- **Labels:** Work Sans is introduced sparingly for functional UI labels and metadata, providing a neutral, utilitarian counterpoint to the more expressive primary fonts.

## Layout & Spacing

The layout follows a **Fixed Grid** model to mirror the constraints of physical print media. 

- **The Golden Ratio:** Use large, asymmetrical margins to push content into focus.
- **Whitespace as Content:** Padding and margins should be treated as structural elements. Vertical spacing between sections should be aggressive (minimum 128px) to allow the "ink" to breathe.
- **Alignment:** Content is primarily left-aligned to mimic manuscript standards, with vertical "rhythm" lines strictly enforced via 8px increments.

## Elevation & Depth

This design system avoids artificial shadows and lighting effects to maintain its flat, editorial integrity. Depth is achieved through **Tonal Layering** and **Line Work**.

- **Surface Tiers:** Use subtle shifts from the Parchment background to the Milled Stone (#E8E4D9) for cards and containers.
- **Structural Lines:** Use 1px solid borders in the Primary Slate Navy color at low opacity (10-15%) to define zones without adding visual weight.
- **Zero-Shadow Policy:** No drop shadows are permitted. Overlays should use a slight background tint or a solid border stroke to indicate focus rather than elevation.

## Shapes

The shape language is strictly **Sharp**. In keeping with the "Curated Manuscript" theme, all buttons, containers, and inputs utilize 0px border radii. This reinforces the precision of a guillotine-cut paper edge and the rigidity of professional typesetting. All structural elements must align perfectly to the pixel grid to maintain the crisp, high-end aesthetic.

## Components

- **Buttons:** Primary buttons are solid Slate Navy with Parchment text. Secondary buttons are transparent with a 1px Slate Navy border. All buttons use the Label-Caps (Work Sans) typography.
- **Input Fields:** Minimalist underlines or 1px strokes. Focus states are indicated by a weight increase in the border stroke (from 1px to 2px), never a color change or glow.
- **Cards:** Used sparingly. Cards should have no shadow, a 1px border (#E8E4D9), and generous internal padding (min 32px).
- **Chips/Tags:** Rectangular, sharp-edged boxes with a Milled Stone background and Slate Navy text in Work Sans 10px Bold.
- **Lists:** Unstyled or utilizing a custom Slate Navy "dash" rather than a standard bullet point to maintain the manuscript aesthetic.
- **Vertical Accents:** Use 1px vertical lines to separate columns or lead the eye through long-form text, mimicking the columns of a high-end newspaper.