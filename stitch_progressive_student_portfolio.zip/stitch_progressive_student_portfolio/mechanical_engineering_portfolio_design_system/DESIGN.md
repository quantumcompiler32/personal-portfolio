---
name: Mechanical Engineering Portfolio Design System
colors:
  surface: '#fbf9fa'
  surface-dim: '#dbd9db'
  surface-bright: '#fbf9fa'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3f4'
  surface-container: '#efedef'
  surface-container-high: '#e9e8e9'
  surface-container-highest: '#e4e2e3'
  on-surface: '#1b1c1d'
  on-surface-variant: '#43474c'
  inverse-surface: '#303032'
  inverse-on-surface: '#f2f0f2'
  outline: '#74777d'
  outline-variant: '#c4c6cd'
  surface-tint: '#4e6073'
  primary: '#162839'
  on-primary: '#ffffff'
  primary-container: '#2c3e50'
  on-primary-container: '#96a9be'
  inverse-primary: '#b5c8df'
  secondary: '#5e5e5e'
  on-secondary: '#ffffff'
  secondary-container: '#e1dfdf'
  on-secondary-container: '#626262'
  tertiary: '#362308'
  on-tertiary: '#ffffff'
  tertiary-container: '#4e381c'
  on-tertiary-container: '#c1a17d'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d1e4fb'
  primary-fixed-dim: '#b5c8df'
  on-primary-fixed: '#091d2e'
  on-primary-fixed-variant: '#36485b'
  secondary-fixed: '#e4e2e2'
  secondary-fixed-dim: '#c7c6c6'
  on-secondary-fixed: '#1b1c1c'
  on-secondary-fixed-variant: '#464747'
  tertiary-fixed: '#ffddb7'
  tertiary-fixed-dim: '#e3c19b'
  on-tertiary-fixed: '#291802'
  on-tertiary-fixed-variant: '#5a4225'
  background: '#fbf9fa'
  on-background: '#1b1c1d'
  surface-variant: '#e4e2e3'
typography:
  display:
    fontFamily: Inter
    fontSize: 72px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.6'
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '500'
    lineHeight: '1.6'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-technical:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: 0.05em
  caption:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.6'
spacing:
  unit: 4px
  gutter: 24px
  margin-page: 64px
  section-gap: 128px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 32px
---

## Brand & Style
The design system is rooted in the aesthetics of technical documentation, architectural blueprints, and high-end museum curation. It prioritizes the objective presentation of mechanical engineering work over decorative flourishes. The personality is clinical, precise, and authoritative, evoking the feeling of a permanent archive.

The design style is a hybrid of **Minimalism** and **Strict Functionalism**. It avoids all forms of skeuomorphism, opting for a digital "white-cube" gallery approach where whitespace is a structural component rather than a void. Every element is governed by logic and necessity, mirroring the discipline of engineering itself.

## Colors
This design system utilizes a high-contrast, restricted palette to maintain a curatorial atmosphere. 

- **Background (#FFFFFF)**: The primary canvas, used to create expansive whitespace.
- **Surface (#F9F9F9)**: Used for secondary containers, technical spec sheets, or to distinguish between adjacent content zones without using shadows.
- **Primary Text (#111111)**: Used for all headlines and critical data points to ensure maximum legibility.
- **Secondary Text (#666666)**: Reserved for annotations, captions, and metadata.
- **Primary Accent (#2C3E50)**: A Slate Navy used sparingly for calls to action or to highlight active states in navigation.
- **Destructive (#D93025)**: A technical red for errors or critical warnings.

Color should never be used for decoration; it is exclusively a tool for hierarchy and information signaling.

## Typography
The typography in this design system is purely utilitarian, utilizing **Inter** for its neutral, highly legible, and systematic qualities. 

The 1.6 line-height is strictly enforced for body copy to ensure clarity in technical descriptions. For metadata and engineering specifications, use the `label-technical` style, which features uppercase styling and increased letter spacing to emulate the look of industrial component labeling. Headlines should remain high-contrast and authoritative, often paired with 1px hairline dividers to separate chapters of work.

## Layout & Spacing
This design system follows a **Fixed Grid** philosophy built on a 12-column layout. Alignment is absolute; elements must snap to the grid lines without exception. 

- **Focal Point Per Screen**: Each viewport should ideally contain only one primary visual or conceptual anchor, surrounded by significant whitespace to focus the viewer's attention.
- **Hairline Dividers**: Use 1px borders (#E5E5E5) to define layout boundaries instead of shadows or color blocks.
- **Section Gaps**: Use aggressive vertical spacing (128px+) between major project sections to maintain a "gallery wall" effect where each piece of content is given room to breathe.

## Elevation & Depth
In this design system, there is no Z-axis depth created through lighting or shadows. All hierarchy is expressed through:

1.  **Tonal Layering**: Using the `Surface` color (#F9F9F9) to denote nested or auxiliary information against the `Background` (#FFFFFF).
2.  **Strict Outlines**: 1px hairline borders (#E5E5E5) are the primary tool for containment.
3.  **Contrast**: Heavy black text against white backgrounds creates visual prominence.

Avoid all blurs, transparency (except for technical overlays), and shadows. The interface should feel as flat and structured as a printed technical manual.

## Shapes
The shape language is defined by absolute 0px border radii. Every container, button, and input field must have sharp, 90-degree corners. 

This rejection of rounding emphasizes the "engineered" nature of the content. Visual interest is generated through the intersection of lines and the precise alignment of rectangles, rather than organic or soft forms.

## Components

### Buttons
Buttons are solid rectangles with 0px radius. The primary action uses the `Primary Accent` (#2C3E50) with white text. Secondary buttons use a 1px border (#E5E5E5) with `Primary Text`. There are no hover gradients; hover states should be indicated by a simple color inversion or a shift in border weight.

### Cards & Containers
Cards are defined by a 1px hairline border. No shadows are permitted. The header of a card should be separated from the body by a horizontal 1px line. Surfaces within cards may use #F9F9F9 for "spec-sheet" style data zones.

### Input Fields
Inputs are stark. They may either be a 4-sided 1px box or a single 1px bottom border. Labels use `label-technical` and are always positioned above the input field, never as placeholder text.

### Technical Data Tables
Tables are essential for an engineering portfolio. Use 1px horizontal dividers only; omit vertical dividers to maintain a modern look. Row heights should be generous, following the 1.6 line-height principle.

### Project Focal Points
A custom component for this design system is the "Technical Focal Point"—a full-width container with a #F9F9F9 background used to display high-resolution schematics, CAD renders, or photography, flanked by large margins of #FFFFFF.